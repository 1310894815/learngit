Git is a version control system.
Git is free software.

Git is a distributed version control system.
Git is free software.
