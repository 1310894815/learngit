<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
    </head>
    <p>下面是搜索<?php echo e($query); ?>的数据,共<?php echo e($posts->total()); ?>条
        <form action="/posts/searchlist" method="get">

            标题搜索：<input type="text" name="query">


            <input type="submit" value="提交">

        </form>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($list->title); ?>------<?php echo e($list->content); ?></p>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br />

    </body>
</html>
<?php /**PATH D:\www\laravel\resources\views/post/searchlist.blade.php ENDPATH**/ ?>